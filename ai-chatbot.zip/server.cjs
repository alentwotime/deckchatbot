const express = require('express');
const multer = require('multer');
const Tesseract = require('tesseract.js');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

function rectangleArea(length, width) {
  return length * width;
}
function circleArea(radius) {
  return Math.PI * Math.pow(radius, 2);
}
function triangleArea(base, height) {
  return (base * height) / 2;
}
function polygonArea(points) {
  let area = 0;
  const n = points.length;
  for (let i = 0; i < n; i++) {
    const { x: x1, y: y1 } = points[i];
    const { x: x2, y: y2 } = points[(i + 1) % n];
    area += (x1 * y2 - x2 * y1);
  }
  return Math.abs(area / 2);
}
function calculatePerimeter(points) {
  let perimeter = 0;
  const n = points.length;
  for (let i = 0; i < n; i++) {
    const { x: x1, y: y1 } = points[i];
    const { x: x2, y: y2 } = points[(i + 1) % n];
    const length = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    perimeter += length;
  }
  return perimeter;
}

// Serve static files (like index.html!)
app.use(express.static(path.join(__dirname)));

// API Endpoints
app.post('/calculate-multi-shape', (req, res) => {
  const { shapes, wastagePercent = 0 } = req.body;
  if (!shapes || !Array.isArray(shapes) || shapes.length === 0) {
    return res.status(400).json({ error: 'Please provide an array of shapes.' });
  }
  let totalArea = 0;
  let poolArea = 0;
  shapes.forEach(shape => {
    const { type, dimensions, isPool } = shape;
    let area = 0;
    if (type === 'rectangle') {
      area = rectangleArea(dimensions.length, dimensions.width);
    } else if (type === 'circle') {
      area = circleArea(dimensions.radius);
    } else if (type === 'triangle') {
      area = triangleArea(dimensions.base, dimensions.height);
    } else if (type === 'polygon') {
      area = polygonArea(dimensions.points);
    } else {
      return res.status(400).json({ error: `Unsupported shape type: ${type}` });
    }
    if (isPool) {
      poolArea += area;
    } else {
      totalArea += area;
    }
  });
  const deckArea = totalArea - poolArea;
  const adjustedDeckArea = deckArea * (1 + wastagePercent / 100);
  res.json({
    totalShapeArea: totalArea.toFixed(2),
    poolArea: poolArea.toFixed(2),
    usableDeckArea: deckArea.toFixed(2),
    adjustedDeckArea: adjustedDeckArea.toFixed(2),
    note: wastagePercent ? `Adjusted for ${wastagePercent}% wastage.` : 'No wastage adjustment.'
  });
});

app.post('/upload-measurements', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload an image.' });
    }
    const { data: { text } } = await Tesseract.recognize(req.file.buffer, 'eng', {
      logger: info => console.log(info),
    });
    const numberPattern = /(\d+(\.\d+)?)/g;
    const matches = text.match(numberPattern);
    if (!matches || matches.length < 6) {
      return res.status(400).json({
        error: 'Not enough numbers detected. Please ensure your measurements are clearly labeled.',
      });
    }
    const totalNumbers = matches.map(Number);
    const midpoint = totalNumbers.length / 2;
    const outerPoints = [];
    for (let i = 0; i < midpoint; i += 2) {
      outerPoints.push({ x: totalNumbers[i], y: totalNumbers[i + 1] });
    }
    const poolPoints = [];
    for (let i = midpoint; i < totalNumbers.length; i += 2) {
      poolPoints.push({ x: totalNumbers[i], y: totalNumbers[i + 1] });
    }
    const outerArea = polygonArea(outerPoints);
    const poolArea = polygonArea(poolPoints);
    const deckArea = outerArea - poolArea;
    const railingFootage = calculatePerimeter(outerPoints);
    res.json({
      outerDeckArea: outerArea.toFixed(2),
      poolArea: poolArea.toFixed(2),
      usableDeckArea: deckArea.toFixed(2),
      railingFootage: railingFootage.toFixed(2)
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error processing image.' });
  }
});

app.post('/chatbot', (req, res) => {
  const { message } = req.body;
  let response = `I'm here to help with your decking projects! I can calculate:
✅ Deck square footage (simple or with a pool)
✅ Railing footage
✅ Wastage adjustments
✅ Complex shapes (upload photo!)
Just tell me what you need!`;
  if (message && message.toLowerCase().includes('pool')) {
    response = `To calculate deck area around a pool, provide:
- Deck length and width
- Pool shape (rectangle, circle, or polygon)
- Pool dimensions
Or upload a photo of your measurements!`;
  }
  res.json({ response });
});

// Final fallback: show index.html for all other GET requests
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(port, () => {
  console.log(`✅ Decking Chatbot Server running at http://localhost:${port}`);
});